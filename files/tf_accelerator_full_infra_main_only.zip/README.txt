# Terraform Automation Accelerator (Snowflake) — Full Infra (Single TF)

This repository contains a **single Terraform-style `.tf` file** designed for the **TF ZIP → SQL → Apply** Streamlit Accelerator inside Snowflake.

The Streamlit app:
1. Accepts a ZIP containing `.tf` files
2. Parses Terraform resources
3. Generates an ordered SQL execution plan
4. Executes the plan using `SP_APPLY_PLAN`
5. Stores plan + execution logs in Snowflake tables

---

## What This TF File Creates

### 1) Database & Schemas
**Database**
- `TF_ACCEL_DB`

**Schemas**
- `TF_ACCEL_DB.RAW` — raw/ingestion zone  
- `TF_ACCEL_DB.CURATED` — curated/analytics zone  
- `TF_ACCEL_DB.APP` — app metadata / access tables  

---

### 2) Warehouse
**Warehouse**
- `TF_ACCEL_WH`  
  - Size: `XSMALL`
  - Auto suspend: `60s`
  - Auto resume: `TRUE`

Used for tasks and queries.

---

### 3) Roles & Role Hierarchy
**Roles**
- `TF_ACCEL_ADMIN`
- `TF_ACCEL_DEV`
- `TF_ACCEL_ANALYST`

**Role inheritance**
- `TF_ACCEL_ADMIN` inherits `TF_ACCEL_DEV`
- `TF_ACCEL_DEV` inherits `TF_ACCEL_ANALYST`

This creates a simple access ladder:
`ADMIN > DEV > ANALYST`

---

### 4) Users
**Users**
- `TF_ACCEL_DEV_USER` (default role: `TF_ACCEL_DEV`)
- `TF_ACCEL_ANALYST_USER` (default role: `TF_ACCEL_ANALYST`)

**Role assignments**
- `TF_ACCEL_DEV` → `TF_ACCEL_DEV_USER`
- `TF_ACCEL_ANALYST` → `TF_ACCEL_ANALYST_USER`

> Note: Emails are placeholders (`dev@example.com`, `analyst@example.com`).

---

### 5) Grants (RBAC)
**Database usage**
- `USAGE` on database `TF_ACCEL_DB` to:
  - `TF_ACCEL_ADMIN`
  - `TF_ACCEL_DEV`
  - `TF_ACCEL_ANALYST`

**Schema usage**
- `USAGE` on schema `TF_ACCEL_DB.RAW` to `TF_ACCEL_ANALYST`
- `USAGE` on schema `TF_ACCEL_DB.CURATED` to `TF_ACCEL_ANALYST`
- `USAGE` + `CREATE TABLE` + `CREATE VIEW` on schema `TF_ACCEL_DB.CURATED` to `TF_ACCEL_DEV`
- `USAGE` + `CREATE TABLE` on schema `TF_ACCEL_DB.APP` to `TF_ACCEL_DEV`

**Warehouse access**
- `USAGE` on warehouse `TF_ACCEL_WH` to:
  - `TF_ACCEL_DEV`
  - `TF_ACCEL_ANALYST`
- `USAGE` + `OPERATE` + `MONITOR` on warehouse `TF_ACCEL_WH` to:
  - `TF_ACCEL_ADMIN`

---

## Data Objects Created

### 6) Internal Stage
- `TF_ACCEL_DB.RAW.ORDERS_STAGE`

Used as an internal stage reference for Snowpipe-style COPY.

---

### 7) Tables (Curated + App)
**Curated tables**
- `TF_ACCEL_DB.CURATED.CUSTOMER`
  - `CUSTOMER_ID NUMBER(38,0) NOT NULL`
  - `EMAIL VARCHAR`
  - `REGION VARCHAR`
  - `AMOUNT NUMBER(12,2)`

- `TF_ACCEL_DB.CURATED.ORDERS`
  - `ORDER_ID NUMBER(38,0) NOT NULL`
  - `CUSTOMER_ID NUMBER(38,0) NOT NULL`
  - `ORDER_TS TIMESTAMP_NTZ`
  - `STATUS VARCHAR`
  - `TOTAL NUMBER(12,2)`

**App table**
- `TF_ACCEL_DB.APP.USER_REGION_ACCESS`
  - `USER_NAME VARCHAR NOT NULL`
  - `REGION VARCHAR NOT NULL`

This table is used by the Row Access Policy to filter rows by region.

---

### 8) View
- `TF_ACCEL_DB.CURATED.V_CUSTOMER_SPEND`

Aggregates spend by customer and region by joining:
- `CURATED.CUSTOMER`
- `CURATED.ORDERS`

---

### 9) Stream
- `TF_ACCEL_DB.CURATED.ORDERS_STREAM`

Tracks change data on the `ORDERS` table.

> In the TF file, `on_table = "ORDERS"` is used (no DB.SCHEMA).
> The Streamlit parser expands it internally to `TF_ACCEL_DB.CURATED.ORDERS`.

---

### 10) Task
- `TF_ACCEL_DB.CURATED.TASK_DAILY_AGG`

Schedule:
- `USING CRON 0 2 * * * UTC`

Task SQL:
- Creates/Replaces `TF_ACCEL_DB.CURATED.DAILY_SALES_AGG`  
- Aggregates daily counts and revenue from `CURATED.ORDERS`

---

### 11) Pipe (Template Snowpipe)
- `TF_ACCEL_DB.RAW.PIPE_ORDERS`

Runs this COPY statement:
- Loads into `TF_ACCEL_DB.CURATED.ORDERS`
- Reads from `@TF_ACCEL_DB.RAW.ORDERS_STAGE`
- CSV file format with header skipped
- `ON_ERROR = CONTINUE`

> Note: This is a template-like pipe. Actual file ingestion still depends on files being present in the stage.

---

## Governance Created (Security)

### 12) Masking Policy (Email)
**Policy**
- `TF_ACCEL_DB.CURATED.MP_MASK_EMAIL`

Logic:
- If role is `TF_ACCEL_ADMIN` → show real email
- Else → show `***MASKED***`

**Attached to**
- `TF_ACCEL_DB.CURATED.CUSTOMER.EMAIL`

---

### 13) Row Access Policy (Region)
**Policy**
- `TF_ACCEL_DB.CURATED.RAP_BY_REGION`

Logic:
- If role is `TF_ACCEL_ADMIN` → allow all rows
- Else → allow only rows where:
  - current user exists in `TF_ACCEL_DB.APP.USER_REGION_ACCESS`
  - and region matches

**Attached to**
- `TF_ACCEL_DB.CURATED.CUSTOMER` ON column `REGION`

---

## Outputs
Terraform outputs included (for reference only):
- `database = TF_ACCEL_DB`
- `warehouse = TF_ACCEL_WH`
- `schemas = [RAW, CURATED, APP]`

---

## How to Run (High Level)
1. Zip your `.tf` file(s)
2. Upload ZIP in the Streamlit app (Upload tab)
3. Click **Generate SQL Plan** (Plan tab)
4. Review SQL
5. Click **EXECUTE PLAN** (Apply & Logs tab)
6. Check execution logs and fix any failures

---

## Notes / Limitations
- The accelerator is a **Terraform-like parser**, not a full Terraform engine.
- Keep **one attribute per line** (important for parsing).
- Nested blocks like `signature {}` and `column {}` are supported.
- Pipes/Tasks require correct privileges (usually solved by executing apply procedure as owner).
- To enforce Row Access properly, you must populate:
  - `TF_ACCEL_DB.APP.USER_REGION_ACCESS`

Example:
```sql
INSERT INTO TF_ACCEL_DB.APP.USER_REGION_ACCESS (USER_NAME, REGION)
VALUES ('TF_ACCEL_ANALYST_USER', 'APAC');